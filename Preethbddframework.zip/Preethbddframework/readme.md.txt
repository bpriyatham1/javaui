# javabdd

# Pre-requisites:
Java,Maven installed and environmental path should be set up
Can be run from eclipse ide or Command prompt
Cucumber Eclipse Plugin V 0.0.22.2, Natural 0.7.6, TestNg plugin
Latest ChromeBrowser for Windows OS

Dropbox account should created and credentials can be used as parameters in the feature files
Example: replace the credentials below in place of "testqa3e322@gmail.com" and "asdsadsa" with any dropbox credentials
these credentials can be changed for all feture files 
make sure "indentation" should be correct while changing the feture files

# Editing the test data
File location: src/test/resources/features/Login.feature
========================================================
@LoginTest @LogoutTest
Scenario: Login as a valid User to Dropbox Account and Logout
	Given I navigate to the Dropbox Homepage 
	When I click on the Login button and enter the below credentials 
		| username  				    | password   |
		| testqa3e322@gmail.com | asdsadsa   |
	Then The login is successfull
	When I click on the Signout button 
	Then The user is successfuly logged out
 
Path location can be replaced with any file from your local pc
File location: src/test/resources/features/UploadFiles.feature
========================================================
@FolderTests @UploadFile
Scenario: Upload a file dropbox account 
	When I upload a file from path "C:\Users\preeth\Downloads\Newfolder\1.txt"
	Then the file is uploaded successfully
	When I click on the Signout button 
	Then The user is successfuly logged out
  
  
  # Run the tests: 
  from Eclipse IDE: right click on project -> maven -> update  project -> once there are no errors run the tests as below
  right click on testng.xml -> run as -> 
  1) right click on any feature file
  src/test/resources/features
  ===========================
  Run as cucumber feature 
  2)right click on testng.xml file
  Preethbddframework/testng.xml
  ============================
  Runs as testng suite
  mvn clean compile -> make sure there are no errors
  from command prompt:
  mvn verify -> to run the tests
  
  # viewing the results and reports and screenshots
  "Preethbddframework\Extent\extentreport.html"
  Extent report file will be generated here,
  #if any failure scrrenshots will be attached to this repot as well
  
  # failed screenshots are capture here
  Preethbddframework\FailedTestsScreenshots
  
  # Log-files are generated in 3 different formats in below location
  Preethbddframework\optile-logs
  
  # Cucumber advanced reports are generated in below folder
  Preethbddframework\target\cucumber-html-reports 
