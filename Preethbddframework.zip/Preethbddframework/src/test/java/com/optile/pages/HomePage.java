package com.optile.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePage {

    @SuppressWarnings("unused")
	private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }	
	
    @FindBy(how = How.ID, using = "sign-up-in")
    public WebElement signInLink;
    @FindBy(how = How.NAME, using = "login_email")
    public WebElement usernameField;
    @FindBy(how = How.NAME, using = "login_password")
    public WebElement passwordField;
    @FindBy(how = How.XPATH, using = "//div[@class='clearfix']//button[@type='submit']")
    public WebElement signInButton;
    @FindBy(how = How.XPATH, using = "//h1[@class='page-header__heading']")
    public WebElement homePageHeader;
    @FindBy(how = How.XPATH, using = "//img[@class='mc-avatar-image']")
    public WebElement logoImage;
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Sign out')]")
    public WebElement signoutButton;
    @FindBy(how = How.ID, using = "files")
    public WebElement filesLink;
    @FindBy(how = How.XPATH, using = "//div[contains(text(), 'New folder')]")
    public WebElement newFolderLink;
    @FindBy(how = How.XPATH, using = "(.//*[normalize-space(text()) and normalize-space(.)='Members'])[1]/following::input[1]")
    public WebElement newFolderName;
    @FindBy(how = How.XPATH, using = "/html//span[@id='notify-msg']")
    public WebElement getNotificationMessage;
    @FindBy(how = How.XPATH, using = "//span[@class='primary-action-menu__button action-upload mc-button mc-button-primary']")
    public WebElement uploadButton;
    @FindBy(how = How.XPATH, using = "//div[@class='mc-popover-content-scroller']//button[1]")
    public WebElement uploadFileButton;
    @FindBy(how = How.XPATH, using = "//p[@class='mc-snackbar-title']")
    public WebElement uploadNotify;
    @FindBy(how = How.XPATH, using = "(.//*[normalize-space(text()) and normalize-space(.)='Upload to�'])[1]/following::span[2]")
    public WebElement selectFolderFromUploadToPopUp;
    @FindBy(how = How.XPATH, using = "(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::span[1]")
    public WebElement uploadFromUploadToPopUp;
    @FindBy(how = How.XPATH, using = "//input[@placeholder='Search']")
    public WebElement searchBox;
    @FindBy(how = How.XPATH, using = "//input[@class='query search-input search-input--large']")
    public WebElement searchHelp;
  
}