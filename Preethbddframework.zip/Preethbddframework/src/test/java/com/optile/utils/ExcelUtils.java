/*
 * Purpose of this Class to make use of
 * DataDriven Testing from Excel Sheet
 * by specifying the TestData in Excel Sheet
 */
package com.optile.utils;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;

/**
 * @author priyatham.bolli
 */
public class ExcelUtils {


    public static XSSFWorkbook wb;
    public static XSSFSheet sheet;
    public static String cellValue;

    public ExcelUtils(String excelPath) {
        try {
            FileInputStream fis = new FileInputStream(excelPath);

            wb = new XSSFWorkbook(fis);
        } catch (Exception e) {
            System.out.println("Excel Exception" + e.getMessage());
        }
    }

    public String GetData(String sheetName, int rowNumber, int columnNumber) {
        sheet = wb.getSheet(sheetName);

        DataFormatter formatter = new DataFormatter();

        cellValue = formatter.formatCellValue(sheet.getRow(rowNumber).getCell(columnNumber));

        return cellValue;
    }
    
}