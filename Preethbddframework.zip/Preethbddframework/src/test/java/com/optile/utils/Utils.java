package com.optile.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.optile.tests.BaseTest;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class Utils extends BaseTest {

	public static void clickbtn_using_js(WebElement button) {
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].click()", button);
	}

	public static void cleartext_using_js(WebElement button) {
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].value ='';", button);
	}

	public static boolean waitForJStoLoad() {

		WebDriverWait wait = new WebDriverWait(driver, 30);
		waitForAJaxCalls();

		// wait for Javascript to load
		ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};

		return wait.until(jsLoad);
	}

	public static ExpectedCondition<Boolean> waitForAJaxCalls() {
		return new ExpectedCondition<Boolean>() {

			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return (Boolean) ((JavascriptExecutor) driver)
							.executeScript("return (window.jQuery != null) && (jQuery.active === 0);");
				} catch (Exception e) {
					// no jQuery present
					return true;
				}
			}
		};
	}

	public static String timestamp() {
		return new SimpleDateFormat("'Date-'dd-MMMMM-yyyy'-Time-'hh-mm-ss-SSSS-aaa").format(new Date());
	}

	public static void takeScreenShot(String screenShotName) {

		try {
			File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File dest = new File(
					"src/test/java/com/wirecard/results/SS-" + screenShotName + "-" + timestamp() + ".png");
			FileUtils.copyFile(scr, dest);
		} catch (Exception e) {
			System.out.println("Exception while taking ScreenShot" + e.getMessage());
		}
	}

	public static void takeFullPageScreenShot(String screenShotName) {

		try {
			Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(100))
					.takeScreenshot(driver);
			ImageIO.write(screenshot.getImage(), "PNG", new File(System.getProperty("user.dir")
					+ "/src/test/java/com/wirecard/results/SS-" + screenShotName + "-" + timestamp() + ".png"));
		} catch (Exception e) {
			System.out.println("Exception while taking full ScreenShot" + e.getMessage());
		}
	}

	public static void waitForElementToBeClickable(WebElement element, int timeout) {

		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void waitForElementToBeVisible(WebElement element, int timeout) {

		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public static void validatePageTitle(String title, int timeout) {

		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.titleIs(title));

	}

	public static String GenerateRandomName(int length) {
		String rn = RandomStringUtils.randomAlphabetic(length);
		return rn;
	}

	public static String GenerateRandomNumber(int length) {
		String rn = RandomStringUtils.randomNumeric(length);
		return rn;
	}

	public static int GenerateRandomNumberBetweenRange(int min, int max) {
		return new Random().nextInt((max - min) + 1) + min;
	}

	public static void refreshPage() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.location.reload();");
		// history.go(0);
	}

	public static boolean retryingFindClick(By by) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 3) {
			try {
				JavascriptExecutor js = ((JavascriptExecutor) driver);
				js.executeScript("arguments[0].click()", driver.findElement(by));
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}
		return result;
	}

	public static String getBrowserInfo() {
		return (String) ((JavascriptExecutor) driver).executeScript("return navigator.userAgent;");
	}

	public static String getScreenShot(String name) throws IOException {
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir")+"/FailedTestsScreenshots/"+name+timestamp()+".png";
		//System.currentTimeMillis()
		File dest=new File(path);
		
		FileUtils.copyFile(src, dest);
		return path;

	}
}
