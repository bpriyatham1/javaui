/**
 * Class Log file has methods for printing Logs for different Log Levels like (INFO,WARN,ERROR,FATAL)
 */
package com.optile.utils;

import com.optile.tests.BaseTest;

/**
 * @author priyatham.bolli
 *
 */

public class Log extends BaseTest {

	public static void startTestCase(String testCaseName) {
		log.info("=========================================================================================");
		
		log.info("Starting Execution of TestCase: " + testCaseName);
		
		log.info("=========================================================================================");
	}

	public static void endTestCase(String testCaseName) {
		log.info("=========================================================================================");
		
		log.info(" Ending Execution of TestCase: " + testCaseName);
		
		log.info("=========================================================================================");
	}

	public static void info(String message) {
		Log.info(message);
	}

	public static void warn(String message) {
		Log.warn(message);
	}

	public static void error(String message) {
		Log.error(message);
	}

	public static void fatal(String message) {
		Log.fatal(message);
	}

}
