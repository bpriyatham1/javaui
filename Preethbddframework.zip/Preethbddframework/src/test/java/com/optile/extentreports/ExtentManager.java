package com.optile.extentreports;

import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.optile.tests.BaseTest;
import com.optile.utils.Utils;

public class ExtentManager extends BaseTest {

	private static ExtentReports extent;
	private static ExtentTest test;
	private static ExtentHtmlReporter htmlReporter;
	private static String filePath = System.getProperty("user.dir") + "/Extent/extentreport.html";

	public static ExtentReports GetExtent() {
		if (extent != null) {
			return extent;
		}
		extent = new ExtentReports();
		extent.attachReporter(getHtmlReporter());
		extent.setSystemInfo("Created by", "Priyatham Bolli");
		extent.setSystemInfo("User Name", System.getProperty("user.name"));
		extent.setSystemInfo("OS Name", os);
		extent.setSystemInfo("OS Version Number", System.getProperty("os.version"));
		extent.setSystemInfo("Java Version", System.getProperty("java.version"));
		extent.setSystemInfo("Web Browser", Utils.getBrowserInfo());
		extent.setSystemInfo("Date/Time", new Date().toString());
		return extent;
	}

	private static ExtentHtmlReporter getHtmlReporter() {
		htmlReporter = new ExtentHtmlReporter(filePath);
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("BDD Automation Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setReportName("MDM UI Tests");

		return htmlReporter;
	}

	public static ExtentTest createTest(String name, String description) {
		test = extent.createTest(name, description);
		return test;
	}

}