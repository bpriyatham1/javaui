package com.optile.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BaseTest {

	public static WebDriver driver;
	protected static Properties prop;
	protected static Logger log = Logger.getLogger(BaseTest.class.getName());

	protected static String os = System.getProperty("os.name").toLowerCase();

	public void setup() throws InterruptedException {

		try {
			prop = new Properties();
			FileInputStream inputStream = new FileInputStream("src/main/resources/Properties/config.properties");
			prop.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		driver = new ChromeDriver(options);

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		int implicitTimeoutPeriod = Integer.parseInt(prop.getProperty("implicitTimeout"));
		int pageLoadTimeoutPeriod = Integer.parseInt(prop.getProperty("pageLoadTimeout"));
		int scriptTimeoutPeriod = Integer.parseInt(prop.getProperty("scriptTimeout"));
		driver.manage().timeouts().implicitlyWait(implicitTimeoutPeriod, TimeUnit.MINUTES);
		driver.manage().timeouts().pageLoadTimeout(pageLoadTimeoutPeriod, TimeUnit.MINUTES);
		driver.manage().timeouts().setScriptTimeout(scriptTimeoutPeriod, TimeUnit.MINUTES);
	}

	public void tearDown() {
		driver.quit();
	}
}
