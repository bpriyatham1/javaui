package steps;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.testng.Assert.assertTrue;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;
import com.optile.pages.HomePage;
import com.optile.tests.BaseTest;
import com.optile.utils.Utils;

public class LoginSteps extends BaseTest {

	private HomePage HomePage() {
		HomePage homePage = PageFactory.initElements(driver, HomePage.class);
		return homePage;
	}

	@When("^I click on the Login button and enter the below credentials$")
	public void i_click_on_the_Login_button_and_enter_the_below_credentials(DataTable table) throws Throwable {
		// List<List<String>> data = table.raw();
		List<TableData> users = new ArrayList<TableData>();
		users = table.asList(TableData.class);
		Utils.waitForElementToBeClickable(HomePage().signInLink, 10);
		HomePage().signInLink.click();
		HomePage().usernameField.clear();
		HomePage().usernameField.sendKeys(users.get(0).username);
		HomePage().passwordField.clear();
		HomePage().passwordField.sendKeys(users.get(0).password);
		HomePage().signInButton.click();
		Hooks.test.log(Status.INFO, "Entering the Credentials");
	}

	@Then("^The login is successfull$")
	public void the_login_is_successfull() throws Throwable {
		Utils.validatePageTitle("Home - Dropbox", 10);
		Utils.waitForElementToBeVisible(HomePage().homePageHeader, 5);
		Utils.waitForElementToBeVisible(HomePage().homePageHeader, 5);
		assertTrue(HomePage().homePageHeader.isDisplayed(), "Heading in home page displayed");
		assertTrue(HomePage().logoImage.isDisplayed(), "Login LogoImage in home page displayed");
		Hooks.test.log(Status.INFO, "The login is successfull");
	}

	@When("^I click on the Signout button$")
	public void i_click_on_the_SigOut_button() throws Throwable {
		Utils.waitForElementToBeClickable(HomePage().logoImage, 5);
		HomePage().logoImage.click();
		Utils.waitForElementToBeClickable(HomePage().signoutButton, 10);
		HomePage().signoutButton.click();
		Hooks.test.log(Status.INFO, "clicked on the signout button");
	}

	@Then("^The user is successfuly logged out$")
	public void the_user_is_successfuly_logged_out() throws Throwable {
		Utils.validatePageTitle("Login - Dropbox", 10);
		assertTrue(driver.getCurrentUrl().contains("logout"));
		Hooks.test.log(Status.INFO, "Signed out successfully");
	}

	@When("^I click Create NewFolder$")
	public void i_click_Create_NewFolder() throws Throwable {
		Utils.waitForElementToBeVisible(HomePage().filesLink, 5);
		HomePage().filesLink.click();
		HomePage().newFolderLink.click();
		Utils.waitForElementToBeClickable(HomePage().newFolderName, 5);
		HomePage().newFolderName.clear();
		HomePage().newFolderName.sendKeys(foldername);
		HomePage().newFolderName.sendKeys(Keys.ENTER);
		Thread.sleep(1500);
		Hooks.test.log(Status.INFO, "Creating a new folder");
	}

	@Then("^A Newfolder is created successfully$")
	public void a_Newfolder_is_created_successfully() throws Throwable {
		Utils.waitForElementToBeVisible(HomePage().getNotificationMessage, 5);
		assertTrue(HomePage().getNotificationMessage.getText().contains("Created folder"));
		Hooks.test.log(Status.INFO, "Newfolder is created successfully");
	}
	
	@When("^I upload a file from path \"([^\"]*)\"$")
	public void i_upload_a_file_from_path(String filepath) throws Throwable {
		Utils.waitForElementToBeClickable(HomePage().uploadButton, 5);
		HomePage().uploadButton.click();
		Utils.waitForElementToBeVisible(HomePage().uploadFileButton, 5);
		HomePage().uploadFileButton.click();		
		Robot robot = new Robot();
		robot.setAutoDelay(2000);
		StringSelection ss = new StringSelection(filepath); 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Utils.waitForElementToBeClickable(HomePage().selectFolderFromUploadToPopUp, 5);
		HomePage().selectFolderFromUploadToPopUp.click();
		Utils.waitForElementToBeClickable(HomePage().selectFolderFromUploadToPopUp, 5);
		HomePage().uploadFromUploadToPopUp.click();
		Hooks.test.log(Status.INFO, "Uploading new file from the path: '"+ filepath +"'");
	}

	@Then("^the file is uploaded successfully$")
	public void the_file_is_uploaded_successfully() throws Throwable {
	    assertTrue(HomePage().uploadNotify.getText().contains("Uploading"));
	    Hooks.test.log(Status.INFO, "file is uploading");
	    Thread.sleep(2000);
	    assertTrue(HomePage().uploadNotify.getText().contains("Uploaded"));
	    Hooks.test.log(Status.INFO, "file is uploaded successfully");
	}

	@When("^I search for a file \"([^\"]*)\"$")
	public void i_search_for_a_file(String keyword) throws Throwable {
		HomePage().searchBox.sendKeys(keyword);
		HomePage().searchBox.submit();
		Hooks.test.log(Status.INFO, "Searching for keyword '" + keyword + "'");
	}

	@Then("^search results for searched keyword \"([^\"]*)\" are displayed successfully$")
	public void search_results_for_searched_keyword_are_displayed_successfully(String keyword) throws Throwable {
		Utils.validatePageTitle("Files - Dropbox", 10);
		assertTrue(driver.getCurrentUrl().contains(keyword));
		Hooks.test.log(Status.INFO, "Search for keyword '" + keyword + "' is successfull");
	}
	
	@When("^I search for help on a topic \"([^\"]*)\"$")
	public void i_search_for_help_on_a_topic(String helptopic) throws Throwable {
	    driver.get(prop.getProperty("helpUrl"));
		Utils.validatePageTitle("Help center � Dropbox Help", 10);
		Utils.waitForElementToBeClickable(HomePage().searchHelp, 10);
		HomePage().searchHelp.sendKeys(helptopic);
		HomePage().searchHelp.sendKeys(Keys.ENTER);
	}

	@Then("^I get the information related to the product \"([^\"]*)\" searched$")
	public void i_get_the_information_related_to_the_product_searched(String helptopic) throws Throwable {
		Utils.validatePageTitle("Search results � Dropbox Help", 10);
		Hooks.test.log(Status.INFO, "Search for keyword '" + helptopic + "' is successfull");
	}
	
	public class TableData {
		public String username;
		public String password;

		public TableData(String userName, String passWord) {
			username = userName;
			password = passWord;
		}
	}
	
	final String foldername = "test"+Utils.GenerateRandomName(5);
}
