package steps;

import cucumber.api.java.en.Given;

import com.aventstack.extentreports.Status;
import com.optile.tests.BaseTest;
import com.optile.utils.Utils;
import steps.Hooks;

public class CommanSteps extends BaseTest {

	@Given("^I navigate to the Dropbox Homepage$")
	public void i_navigate_to_the_Dropbox_Homepage() throws Throwable {

		driver.get(prop.getProperty("devEnvUrl"));
		Utils.validatePageTitle("Dropbox", 20);
		Hooks.test.log(Status.INFO, "Opened Dropbox Home Page Successfully");		
		log.info("Opened Dropbox Home Page Successfully");
	}

}
