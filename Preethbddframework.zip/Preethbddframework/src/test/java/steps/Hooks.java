package steps;

import java.io.IOException;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.optile.extentreports.ExtentManager;
import com.optile.tests.BaseTest;
import com.optile.utils.Log;
import com.optile.utils.Utils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends BaseTest {

	public static Scenario scenario;
	public static ExtentReports extent;
	public static ExtentTest test;

	@Before
	public void InitializeTest(Scenario scenario) throws InterruptedException {
		setup();
		Hooks.scenario = scenario;
		Log.startTestCase(scenario.getName());
		log.info("Apache Log Info: ======================= Opening the Web Browser=========================");
		log.info("Name of the Scenario:			" + scenario.getName());
		extent = ExtentManager.GetExtent();
		test = extent.createTest(scenario.getName());
		test.log(Status.INFO, "Test Execution of scenario '" + scenario.getName() + "' is started");
	}

	@After
	public void TearDownTest(Scenario scenario) throws IOException {
		Log.endTestCase(scenario.getName());
		log.info("Apache Log Info: ======================= Closing the Web Browser=========================");
		if (scenario.getStatus() == "passed") {
			test.log(Status.PASS, "The Test named as : " + scenario.getName() + "is passed");
		} else if (scenario.getStatus() == "failed") {
			test.log(Status.FAIL, "The Test named as : " + scenario.getName() + "is failed");

			String path = Utils.getScreenShot(scenario.getName());
			test.fail("Test failed as shown in below screenshot",
					MediaEntityBuilder.createScreenCaptureFromPath(path).build());
			test.addScreenCaptureFromPath("/FailedTestsScreenshots/screenshot.png");

		} else if (scenario.getStatus() == "skipped") {
			test.log(Status.SKIP, "The Test named as : " + scenario.getName() + "is skipped");
		}
		test.log(Status.INFO, "Test Execution of scenario '" + scenario.getName() + "' is finished");
		extent.flush();
		tearDown();
	}

}