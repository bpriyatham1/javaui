/**
 * TestRunner.java File is created to run all the Features
 */
package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(
        features = {"src/test/resources/features"},
        monochrome = true,
        plugin = {"json:target/cucumber.json", "html:target/site/cucumber-pretty"},
        tags = {"~@Ignore"},
        glue = {"steps"})

public class TestRunner extends AbstractTestNGCucumberTests {

}